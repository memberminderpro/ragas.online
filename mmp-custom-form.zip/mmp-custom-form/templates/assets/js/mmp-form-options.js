// mmpFormOptions.js

const mmpFormOptions = {
    recaptcha_site_key: "6LfUu-UpAAAAAJy58Tuq2oZxnlTxV5bgtcCWigzP",
    recaptcha_secret_key: "6LfUu-UpAAAAAFL7KXvU05wtrksT7tdOVe1CvUTm",
    account_ID: 10651,
    BID: 1065,
    ClubID: 989306,
    account_email: "wash-rag@rmoore.dev",
    default_member_type_id: 938,
    membership_cost: 25,
    term: 1
};
